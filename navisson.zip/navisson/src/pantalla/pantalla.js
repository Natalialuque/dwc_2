// Clase que representa una pantalla del inventario.
export class pantalla {
    // Constructor: recibe los datos y los guarda en propiedades del objeto.
    constructor(datos) {
        // Referencia unica de la pantalla, siempre en mayusculas.
        this.referencia = String(datos.referencia || datos.id).trim().toUpperCase();
        // Nombre o modelo de la pantalla.
        this.nombre = String(datos.nombre).trim();
        // Tamano convertido a numero.
        this.tamano = Number(datos.tamano);
        // Tipo de pantalla.
        this.tipo = String(datos.tipo).trim();
        // Estado actual de la pantalla.
        this.estado = String(datos.estado).trim();
        // Precio convertido a numero.
        this.precio = Number(datos.precio);
        // Fecha de fabricacion.
        this.fechaFabricacion = datos.fechaFabricacion || datos.FechaFabricacion;
    }

    // Convierte la instancia en un objeto normal para poder guardarlo en JSON.
    convertirObjeto() {
        // Devolvemos solo datos simples.
        return {
            referencia: this.referencia,
            nombre: this.nombre,
            tamano: this.tamano,
            tipo: this.tipo,
            estado: this.estado,
            precio: this.precio,
            fechaFabricacion: this.fechaFabricacion
        };
    }

    // Devuelve el precio con formato de euros.
    obtenerPrecioFormateado() {
        // Intl.NumberFormat formatea el numero segun Espana y moneda EUR.
        return new Intl.NumberFormat("es-ES", {
            style: "currency",
            currency: "EUR"
        }).format(this.precio);
    }

    // Calcula cuantos dias han pasado desde la fabricacion.
    obtenerDiasDesdeFabricacion() {
        // Convertimos la fecha de fabricacion a Date.
        const fecha = new Date(this.fechaFabricacion);
        // Fecha actual.
        const hoy = new Date();
        // Cantidad de milisegundos que tiene un dia.
        const milisegundosDia = 1000 * 60 * 60 * 24;

        // Restamos fechas, dividimos entre dias y evitamos numeros negativos.
        return Math.max(0, Math.floor((hoy - fecha) / milisegundosDia));
    }

    // Metodo estatico para crear pantallas desde objetos normales.
    static crear(datos) {
        // Devuelve una nueva instancia de pantalla.
        return new pantalla(datos);
    }
}
