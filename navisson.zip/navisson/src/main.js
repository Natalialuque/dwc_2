// Importamos la clase pantalla para crear objetos de pantalla.
import { pantalla } from "./pantalla/pantalla.js";
// Importamos la clase nodos para crear la interfaz con document.createElement.
import { nodos } from "./pantalla/nodos.js";
// Importamos el servicio que contiene los fetch.
import { servicioApi } from "./servicios/servicioApi.js";
// Importamos el servicio de localStorage, sessionStorage y cookies.
import { servicioAlmacenamiento } from "./servicios/servicioAlmacenamiento.js";
// Importamos la funcion que valida el formulario.
import { validarPantalla } from "./utilidades/validadores.js";

// Creamos un objeto de la clase nodos.
const creadorNodos = new nodos();
// Creamos toda la estructura HTML dentro del contenedor del index.
creadorNodos.crearAplicacion();

// Llamamos a las variables del HTML para poder usarlas y modificarlas.
const listaPantallas = document.getElementById("listaPantallas");
const lineaEstado = document.getElementById("lineaEstado");

// Variables del formulario.
const formularioPantalla = document.getElementById("formularioPantalla");
const tituloFormulario = document.getElementById("tituloFormulario");
const referenciaEdicion = document.getElementById("referenciaEdicion");
const botonCancelarEdicion = document.getElementById("botonCancelarEdicion");

// Variables de los botones principales.
const botonRecargar = document.getElementById("botonRecargar");
const botonEstadisticas = document.getElementById("botonEstadisticas");
const botonTema = document.getElementById("botonTema");

// Variables de los campos del formulario.
const campoNombre = document.getElementById("nombrePantalla");
const campoReferencia = document.getElementById("referenciaPantalla");
const campoTamano = document.getElementById("tamanoPantalla");
const campoTipo = document.getElementById("tipoPantalla");
const campoEstado = document.getElementById("estadoPantalla");
const campoPrecio = document.getElementById("precioPantalla");
const campoFecha = document.getElementById("fechaPantalla");

// Variables de los mensajes de error del formulario.
const errorNombre = document.getElementById("errorNombrePantalla");
const errorReferencia = document.getElementById("errorReferenciaPantalla");
const errorTamano = document.getElementById("errorTamanoPantalla");
const errorTipo = document.getElementById("errorTipoPantalla");
const errorEstado = document.getElementById("errorEstadoPantalla");
const errorPrecio = document.getElementById("errorPrecioPantalla");
const errorFecha = document.getElementById("errorFechaPantalla");

// Variables de los filtros.
const busquedaPantalla = document.getElementById("busquedaPantalla");
const filtroTipo = document.getElementById("filtroTipo");
const filtroEstado = document.getElementById("filtroEstado");
const ordenPantallas = document.getElementById("ordenPantallas");

// Creamos el worker que filtra y ordena las pantallas.
const trabajador = new Worker("src/trabajadores/trabajadorFiltro.js");

// Array donde guardamos las pantallas creadas o cargadas.
const pantallas = [];

// Variable para recordar si esta activo el fondo oscuro.
let fondoOscuro = true;

// Variable para guardar el clima del taller y mostrarlo solo en estadisticas.
let climaTaller = "No disponible";

// Iniciamos la aplicacion.
iniciarAplicacion();

// Funcion principal de arranque de la aplicacion.
async function iniciarAplicacion() {
    // Asignamos todos los eventos de botones, filtros y formulario.
    asignarEventos();
    // Preparamos el worker para recibir resultados.
    asignarTrabajador();
    // Recuperamos filtros guardados en sessionStorage.
    recuperarFiltros();
    // Recuperamos la cookie del modo oscuro.
    recuperarTema();
    // Cargamos pantallas desde localStorage o desde JSON.
    await cargarDatos();
    // Recuperamos la ultima pantalla pulsada para modificar.
    recuperarUltimaPantallaModificada();
    // Cargamos el clima, pero no lo pintamos en el index.
    await cargarClima();
}

// Funcion donde se asignan los eventos.
function asignarEventos() {
    // Evento submit del formulario para guardar o modificar pantalla.
    formularioPantalla.addEventListener("submit", guardarPantalla);
    // Evento para cancelar la edicion.
    botonCancelarEdicion.addEventListener("click", limpiarFormulario);
    // Evento delegado para los botones de cada tarjeta.
    listaPantallas.addEventListener("click", gestionarClickLista);
    // Eventos de filtros.
    busquedaPantalla.addEventListener("input", aplicarFiltros);
    filtroTipo.addEventListener("change", aplicarFiltros);
    filtroEstado.addEventListener("change", aplicarFiltros);
    ordenPantallas.addEventListener("change", aplicarFiltros);
    // Eventos de botones de la cabecera.
    botonRecargar.addEventListener("click", recargarJson);
    botonEstadisticas.addEventListener("click", abrirVentanaEstadisticas);
    botonTema.addEventListener("click", cambiarTema);

    // Antes de cerrar o recargar guardamos los filtros en sessionStorage.
    window.addEventListener("beforeunload", () => {
        servicioAlmacenamiento.guardarFiltros(leerFiltros());
    });
}

// Funcion que prepara la respuesta del worker.
function asignarTrabajador() {
    // Cuando el worker devuelve datos, pintamos las tarjetas.
    trabajador.addEventListener("message", (evento) => {
        // Convertimos los objetos planos otra vez en objetos de la clase pantalla.
        const pantallasFiltradas = evento.data.map((elemento) => pantalla.crear(elemento));

        // Pintamos las pantallas filtradas.
        pintarPantallas(pantallasFiltradas);
        // Mostramos cuantos resultados hay.
        mostrarEstado(pantallasFiltradas.length + " resultado(s) mostrado(s).");
    });
}

// Funcion para recuperar los filtros guardados.
function recuperarFiltros() {
    // Cargamos filtros desde sessionStorage.
    const filtros = servicioAlmacenamiento.cargarFiltros();

    // Rellenamos los controles del filtro.
    busquedaPantalla.value = filtros.busqueda || "";
    filtroTipo.value = filtros.tipo || "";
    filtroEstado.value = filtros.estado || "";
    ordenPantallas.value = filtros.orden || "nombre";
}

// Funcion para recuperar el tema desde cookie.
function recuperarTema() {
    // Leemos la cookie del fondo oscuro.
    const cookieTema = servicioAlmacenamiento.cargarFondoOscuro();

    // Si no existe, activamos oscuro por defecto y lo guardamos.
    if (cookieTema === "") {
        servicioAlmacenamiento.guardarFondoOscuro(true);
        fondoOscuro = true;
    } else {
        // Si existe, miramos si vale si o no.
        fondoOscuro = cookieTema === "si";
    }

    // Aplicamos el tema a la pagina.
    pintarTemaOscuro();
}

// Funcion para cambiar entre modo oscuro y claro.
function cambiarTema() {
    // Cambiamos el valor booleano.
    fondoOscuro = !fondoOscuro;
    // Guardamos el nuevo valor en cookie.
    servicioAlmacenamiento.guardarFondoOscuro(fondoOscuro);
    // Pintamos el cambio.
    pintarTemaOscuro();
}

// Funcion que aplica la clase CSS del modo oscuro.
function pintarTemaOscuro() {
    // Si fondoOscuro es true, se anade la clase; si es false, se quita.
    document.body.classList.toggle("fondo-oscuro", fondoOscuro);
    // Cambiamos el texto del boton.
    botonTema.textContent = fondoOscuro ? "Modo claro" : "Modo oscuro";
}

// Funcion para cargar pantallas.
async function cargarDatos() {
    // Intentamos leer pantallas guardadas en localStorage.
    const pantallasGuardadas = servicioAlmacenamiento.cargarPantallas();

    // Vaciamos el array antes de llenarlo.
    pantallas.length = 0;

    // Si hay datos guardados, usamos esos datos.
    if (pantallasGuardadas.length > 0) {
        pantallasGuardadas.forEach((pantallaActual) => pantallas.push(pantallaActual));
        mostrarEstado("Inventario recuperado desde localStorage.");
    } else {
        // Si no hay datos guardados, cargamos el JSON inicial con fetch.
        const pantallasJson = await servicioApi.cargarPantallasIniciales();
        // Metemos cada pantalla en el array.
        pantallasJson.forEach((pantallaActual) => pantallas.push(pantallaActual));
        // Guardamos esas pantallas iniciales en localStorage.
        servicioAlmacenamiento.guardarPantallas(pantallas);
        mostrarEstado("Inventario inicial cargado desde JSON.");
    }

    // Actualizamos el listado.
    aplicarFiltros();
}

// Funcion que recupera la ultima pantalla pulsada para editar.
function recuperarUltimaPantallaModificada() {
    // Leemos la referencia guardada en cookie.
    const referencia = servicioAlmacenamiento.cargarUltimaPantallaModificada();
    // Buscamos la pantalla con esa referencia.
    const pantallaModificada = pantallas.find((pantallaActual) => pantallaActual.referencia === referencia);

    // Si existe, rellenamos el formulario.
    if (pantallaModificada) {
        rellenarFormulario(pantallaModificada);
        mostrarEstado("Formulario preparado con la ultima pantalla modificada: " + referencia + ".");
    }
}

// Funcion para recargar desde el JSON original.
async function recargarJson() {
    // Usamos try/catch porque fetch puede fallar.
    try {
        // Cargamos las pantallas del JSON.
        const pantallasJson = await servicioApi.cargarPantallasIniciales();

        // Vaciamos el array actual.
        pantallas.length = 0;
        // Metemos los datos del JSON.
        pantallasJson.forEach((pantallaActual) => pantallas.push(pantallaActual));
        // Guardamos en localStorage.
        servicioAlmacenamiento.guardarPantallas(pantallas);
        // Dejamos el formulario limpio.
        limpiarFormulario();
        // Refrescamos el listado.
        aplicarFiltros();
        // Informamos al usuario.
        mostrarEstado("Datos iniciales recargados desde data/pantallas.json.");
    } catch (error) {
        // Si algo falla, mostramos el mensaje.
        mostrarEstado(error.message);
    }
}

// Funcion para cargar el clima del taller.
async function cargarClima() {
    // Usamos try/catch porque la API externa puede fallar.
    try {
        // Pedimos el clima al servicio.
        const clima = await servicioApi.cargarClimaTaller();
        // Guardamos el dato actual en una variable.
        const actual = clima.current;

        // No se muestra en el index; solo se guarda para estadisticas.
        climaTaller = actual.temperature_2m + " C - viento " + actual.wind_speed_10m + " km/h";
    } catch (error) {
        // Si falla, dejamos un texto de reserva.
        climaTaller = "No disponible";
        console.warn(error);
    }
}

// Funcion para guardar una pantalla nueva o modificar una existente.
async function guardarPantalla(evento) {
    // Evitamos que el formulario recargue la pagina.
    evento.preventDefault();

    // Leemos todos los campos del formulario.
    const datosFormulario = leerFormulario();
    // Miramos si estamos editando una pantalla.
    const referenciaActual = referenciaEdicion.value;
    // Validamos los datos antes de guardar.
    const validacion = validarPantalla(datosFormulario, pantallas, referenciaActual);

    // Si hay errores, los mostramos y salimos.
    if (!validacion.esValido) {
        pintarErrores(validacion.errores);
        mostrarEstado("Revisa los campos marcados antes de guardar.");
        return;
    }

    // Creamos una instancia de pantalla con los datos del formulario.
    const pantallaNueva = new pantalla(datosFormulario);

    // Si referenciaActual tiene valor, estamos modificando.
    if (referenciaActual) {
        // Recorremos el array para sustituir la pantalla modificada.
        for (let i = 0; i < pantallas.length; i++) {
            if (pantallas[i].referencia === referenciaActual) {
                pantallas[i] = pantallaNueva;
            }
        }

        // Guardamos en cookie la ultima pantalla modificada.
        servicioAlmacenamiento.guardarUltimaPantallaModificada(pantallaNueva);
        // Mostramos mensaje.
        mostrarEstado("Pantalla " + pantallaNueva.referencia + " actualizada correctamente.");
    } else {
        // Si no estamos modificando, anadimos la pantalla al array.
        pantallas.push(pantallaNueva);
        // Mostramos mensaje.
        mostrarEstado("Pantalla " + pantallaNueva.referencia + " creada correctamente.");
        // Mandamos una peticion POST de demostracion.
        avisarServidorSinBloquear(pantallaNueva);
    }

    // Guardamos el array en localStorage.
    servicioAlmacenamiento.guardarPantallas(pantallas);
    // Limpiamos el formulario.
    limpiarFormulario();
    // Refrescamos el listado.
    aplicarFiltros();
}

// Funcion para avisar a un servidor de prueba sin bloquear la app.
async function avisarServidorSinBloquear(pantallaActual) {
    // Usamos try/catch porque esta peticion no debe romper la aplicacion.
    try {
        // Enviamos la pantalla con fetch POST.
        await servicioApi.avisarServidor(pantallaActual);
    } catch (error) {
        // Solo dejamos el aviso en consola.
        console.warn("Fetch POST demo fallido", error);
    }
}

// Funcion que gestiona clicks dentro de la lista de pantallas.
function gestionarClickLista(evento) {
    // Buscamos si el click viene de un boton con data-accion.
    const boton = evento.target.closest("button[data-accion]");

    // Si no se ha pulsado un boton de accion, no hacemos nada.
    if (!boton) {
        return;
    }

    // Leemos la accion y la referencia guardadas en data.
    const accion = boton.dataset.accion;
    const referencia = boton.dataset.referencia;
    // Buscamos la pantalla correspondiente.
    const pantallaActual = pantallas.find((elemento) => elemento.referencia === referencia);

    // Si no existe, salimos.
    if (!pantallaActual) {
        return;
    }

    // Accion para ver detalle.
    if (accion === "detalle") {
        abrirVentanaDetalle(pantallaActual);
    }

    // Accion para editar.
    if (accion === "editar") {
        servicioAlmacenamiento.guardarUltimaPantallaModificada(pantallaActual);
        rellenarFormulario(pantallaActual);
        mostrarEstado("Pantalla " + pantallaActual.referencia + " guardada en cookie para modificar.");
    }

    // Accion para eliminar.
    if (accion === "eliminar") {
        eliminarPantalla(pantallaActual);
    }
}

// Funcion para eliminar una pantalla.
function eliminarPantalla(pantallaActual) {
    // Pedimos confirmacion antes de borrar.
    const confirmado = window.confirm("Eliminar la pantalla " + pantallaActual.referencia + "?");

    // Si se cancela, salimos.
    if (!confirmado) {
        return;
    }

    // Recorremos hacia atras para poder borrar con splice.
    for (let i = pantallas.length - 1; i >= 0; i--) {
        if (pantallas[i].referencia === pantallaActual.referencia) {
            pantallas.splice(i, 1);
        }
    }

    // Guardamos cambios.
    servicioAlmacenamiento.guardarPantallas(pantallas);
    // Limpiamos formulario.
    limpiarFormulario();
    // Refrescamos listado.
    aplicarFiltros();
    // Mostramos mensaje.
    mostrarEstado("Pantalla " + pantallaActual.referencia + " eliminada del inventario.");
}

// Funcion que aplica filtros usando el worker.
function aplicarFiltros() {
    // Leemos filtros actuales.
    const filtros = leerFiltros();

    // Guardamos filtros en sessionStorage.
    servicioAlmacenamiento.guardarFiltros(filtros);
    // Mostramos mensaje temporal.
    mostrarEstado("Filtrando con Web Worker...");

    // Enviamos datos al worker.
    trabajador.postMessage({
        pantallas: pantallas.map((pantallaActual) => pantallaActual.convertirObjeto()),
        filtros
    });
}

// Funcion que pinta las pantallas filtradas en el listado.
function pintarPantallas(pantallasFiltradas) {
    // Borramos el contenido anterior.
    listaPantallas.replaceChildren();

    // Si no hay resultados, mostramos estado vacio.
    if (pantallasFiltradas.length === 0) {
        listaPantallas.appendChild(creadorNodos.crearEstadoVacio());
        return;
    }

    // Por cada pantalla creamos una tarjeta con la clase nodos.
    pantallasFiltradas.forEach((pantallaActual) => {
        listaPantallas.appendChild(creadorNodos.crearTarjeta(pantallaActual));
    });
}

// Funcion que lee el formulario.
function leerFormulario() {
    // Devolvemos un objeto con los valores del formulario.
    return {
        nombre: campoNombre.value,
        referencia: campoReferencia.value,
        tamano: campoTamano.value,
        tipo: campoTipo.value,
        estado: campoEstado.value,
        precio: campoPrecio.value,
        fechaFabricacion: campoFecha.value
    };
}

// Funcion que rellena el formulario al editar.
function rellenarFormulario(pantallaActual) {
    // Cambiamos el titulo.
    tituloFormulario.textContent = "Editar pantalla";
    // Guardamos la referencia original en el campo oculto.
    referenciaEdicion.value = pantallaActual.referencia;
    // Rellenamos cada campo.
    campoNombre.value = pantallaActual.nombre;
    campoReferencia.value = pantallaActual.referencia;
    campoTamano.value = pantallaActual.tamano;
    campoTipo.value = pantallaActual.tipo;
    campoEstado.value = pantallaActual.estado;
    campoPrecio.value = pantallaActual.precio;
    campoFecha.value = pantallaActual.fechaFabricacion;
    // Ponemos el foco en el primer campo.
    campoNombre.focus();
}

// Funcion que limpia el formulario.
function limpiarFormulario() {
    // Reseteamos los campos.
    formularioPantalla.reset();
    // Volvemos al titulo inicial.
    tituloFormulario.textContent = "Nueva pantalla";
    // Quitamos la referencia de edicion.
    referenciaEdicion.value = "";
    // Limpiamos errores.
    limpiarErrores();
}

// Funcion que pinta errores campo a campo.
function pintarErrores(errores) {
    // Primero limpiamos errores anteriores.
    limpiarErrores();

    // Error de nombre.
    if (errores.nombre) {
        errorNombre.textContent = errores.nombre;
        campoNombre.classList.add("campo-invalido");
    }

    // Error de referencia.
    if (errores.referencia) {
        errorReferencia.textContent = errores.referencia;
        campoReferencia.classList.add("campo-invalido");
    }

    // Error de tamano.
    if (errores.tamano) {
        errorTamano.textContent = errores.tamano;
        campoTamano.classList.add("campo-invalido");
    }

    // Error de tipo.
    if (errores.tipo) {
        errorTipo.textContent = errores.tipo;
        campoTipo.classList.add("campo-invalido");
    }

    // Error de estado.
    if (errores.estado) {
        errorEstado.textContent = errores.estado;
        campoEstado.classList.add("campo-invalido");
    }

    // Error de precio.
    if (errores.precio) {
        errorPrecio.textContent = errores.precio;
        campoPrecio.classList.add("campo-invalido");
    }

    // Error de fecha.
    if (errores.fechaFabricacion) {
        errorFecha.textContent = errores.fechaFabricacion;
        campoFecha.classList.add("campo-invalido");
    }
}

// Funcion para quitar errores.
function limpiarErrores() {
    // Vaciamos textos de error.
    errorNombre.textContent = "";
    errorReferencia.textContent = "";
    errorTamano.textContent = "";
    errorTipo.textContent = "";
    errorEstado.textContent = "";
    errorPrecio.textContent = "";
    errorFecha.textContent = "";

    // Quitamos clase de error de todos los campos.
    campoNombre.classList.remove("campo-invalido");
    campoReferencia.classList.remove("campo-invalido");
    campoTamano.classList.remove("campo-invalido");
    campoTipo.classList.remove("campo-invalido");
    campoEstado.classList.remove("campo-invalido");
    campoPrecio.classList.remove("campo-invalido");
    campoFecha.classList.remove("campo-invalido");
}

// Funcion que lee los filtros.
function leerFiltros() {
    // Devolvemos los valores actuales de los filtros.
    return {
        busqueda: busquedaPantalla.value.trim(),
        tipo: filtroTipo.value,
        estado: filtroEstado.value,
        orden: ordenPantallas.value
    };
}

// Funcion para escribir mensajes de estado.
function mostrarEstado(mensaje) {
    // Cambiamos el texto de la linea de estado.
    lineaEstado.textContent = mensaje;
}

// Funcion para abrir una ventana con el detalle de una pantalla.
function abrirVentanaDetalle(pantallaActual) {
    // Creamos ventana nueva.
    const ventanaDetalle = window.open("", "detalle-" + pantallaActual.referencia, "width=520,height=620");

    // Si el navegador bloquea la ventana, avisamos.
    if (!ventanaDetalle) {
        mostrarEstado("El navegador ha bloqueado la ventana de detalle.");
        return;
    }

    // Escribimos el HTML de detalle.
    ventanaDetalle.document.write(`
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Detalle ${pantallaActual.referencia}</title>
            <style>
                body { margin: 0; font-family: Arial, sans-serif; color: #20201f; background: #f7f7f6; }
                main { padding: 28px; }
                h1 { margin: 0 0 8px; }
                .ref { color: #6d6d68; margin: 0 0 18px; }
                dl { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
                div { padding: 14px; border-radius: 8px; background: #fff; border-left: 4px solid #D49454; }
                dt { font-weight: 700; }
                dd { margin: 4px 0 0; }
            </style>
        </head>
        <body>
            <main>
                <h1>${pantallaActual.nombre}</h1>
                <p class="ref">${pantallaActual.referencia}</p>
                <dl>
                    <div><dt>Tipo</dt><dd>${pantallaActual.tipo}</dd></div>
                    <div><dt>Estado</dt><dd>${pantallaActual.estado}</dd></div>
                    <div><dt>Tamano</dt><dd>${pantallaActual.tamano}"</dd></div>
                    <div><dt>Precio</dt><dd>${pantallaActual.obtenerPrecioFormateado()}</dd></div>
                    <div><dt>Fabricacion</dt><dd>${pantallaActual.fechaFabricacion}</dd></div>
                    <div><dt>Dias desde fabricacion</dt><dd>${pantallaActual.obtenerDiasDesdeFabricacion()}</dd></div>
                </dl>
            </main>
        </body>
        </html>
    `);
    // Cerramos el documento para que termine de renderizar.
    ventanaDetalle.document.close();
}

// Funcion para abrir una ventana con estadisticas.
function abrirVentanaEstadisticas() {
    // Total de pantallas registradas.
    const total = pantallas.length;
    // Pantallas en stock.
    const stock = pantallas.filter((pantallaActual) => pantallaActual.estado === "En stock").length;
    // Pantallas enviadas.
    const enviadas = pantallas.filter((pantallaActual) => pantallaActual.estado === "Enviada").length;
    // Pantallas defectuosas.
    const defectuosas = pantallas.filter((pantallaActual) => pantallaActual.estado === "Defectuosa").length;
    // Suma de precios para calcular la media.
    const sumaPrecios = pantallas.reduce((suma, pantallaActual) => suma + pantallaActual.precio, 0);
    // Precio medio: suma de todos los precios dividido entre la cantidad de pantallas.
    const media = total === 0 ? 0 : sumaPrecios / total;
    // Pantalla mas cara.
    const masCara = [...pantallas].sort((primera, segunda) => segunda.precio - primera.precio)[0];
    // Creamos ventana nueva.
    const ventanaEstadisticas = window.open("", "navisson-estadisticas", "width=620,height=700");

    // Si el navegador bloquea la ventana, avisamos.
    if (!ventanaEstadisticas) {
        mostrarEstado("El navegador ha bloqueado la ventana de estadisticas.");
        return;
    }

    // Escribimos las estadisticas, incluyendo los datos que ya no aparecen en el index.
    ventanaEstadisticas.document.write(`
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Estadisticas Navisson</title>
            <style>
                body { margin: 0; font-family: Arial, sans-serif; color: #20201f; background: #f7f7f6; }
                main { padding: 28px; }
                h1 { margin-top: 0; }
                section { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
                article { padding: 16px; background: #fff; border-radius: 8px; border-left: 4px solid #D49454; }
                strong { display: block; font-size: 1.6rem; }
                p { margin: 8px 0 0; color: #5f5f5a; }
                @media (max-width: 560px) { section { grid-template-columns: 1fr; } }
            </style>
        </head>
        <body>
            <main>
                <h1>Estadisticas del inventario</h1>
                <section>
                    <article><strong>${total}</strong><span>Pantallas registradas</span></article>
                    <article><strong>${stock}</strong><span>Pantallas en stock</span></article>
                    <article>
                        <strong>${new Intl.NumberFormat("es-ES", { style: "currency", currency: "EUR" }).format(media)}</strong>
                        <span>Precio medio</span>
                        <p>Se obtiene sumando el precio de todas las pantallas y dividiendo esa suma entre la cantidad total de pantallas.</p>
                    </article>
                    <article><strong>${climaTaller}</strong><span>Clima taller</span></article>
                    <article><strong>${enviadas}</strong><span>Pantallas enviadas</span></article>
                    <article><strong>${defectuosas}</strong><span>Pantallas defectuosas</span></article>
                    <article><strong>${masCara ? masCara.nombre : "Sin datos"}</strong><span>Pantalla de mayor precio</span></article>
                </section>
            </main>
        </body>
        </html>
    `);
    // Cerramos el documento de la ventana.
    ventanaEstadisticas.document.close();
}
