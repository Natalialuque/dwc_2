// Importamos la clase pantalla para convertir los datos recibidos en objetos.
import { pantalla } from "../pantalla/pantalla.js";

// Objeto que agrupa las llamadas fetch de la aplicacion.
export const servicioApi = {
    // Carga las pantallas iniciales desde el archivo JSON.
    async cargarPantallasIniciales() {
        // Pedimos el archivo JSON local con fetch.
        const respuesta = await fetch("data/pantallas.json");

        // Si la respuesta no es correcta, lanzamos error.
        if (!respuesta.ok) {
            throw new Error("No se pudo cargar el JSON inicial.");
        }

        // Convertimos la respuesta a JSON.
        const datos = await respuesta.json();
        // Convertimos cada objeto en una instancia de pantalla.
        return datos.map((elemento) => pantalla.crear(elemento));
    },

    // Carga el clima del taller desde una API externa.
    async cargarClimaTaller() {
        // URL de Open-Meteo para Malaga con temperatura y viento actuales.
        const ruta = "https://api.open-meteo.com/v1/forecast?latitude=36.7213&longitude=-4.4214&current=temperature_2m,wind_speed_10m&timezone=Europe%2FMadrid";
        // Pedimos los datos con fetch.
        const respuesta = await fetch(ruta);

        // Si falla, lanzamos error.
        if (!respuesta.ok) {
            throw new Error("No se pudo consultar la API externa.");
        }

        // Devolvemos el JSON de clima.
        return respuesta.json();
    },

    // Envia una pantalla a un servidor de prueba.
    async avisarServidor(pantallaActual) {
        // Hacemos un POST de demostracion.
        const respuesta = await fetch("https://jsonplaceholder.typicode.com/posts", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(pantallaActual.convertirObjeto())
        });

        // Si falla, lanzamos error.
        if (!respuesta.ok) {
            throw new Error("No se pudo enviar la pantalla al servidor demo.");
        }

        // Devolvemos la respuesta JSON.
        return respuesta.json();
    }
};
